package com.trabalhoOO.agencia.model;

public enum TipoPassageiro {
	ADULTO, CRIANÇA;
}
