package com.trabalhoOO.agencia.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trabalhoOO.agencia.model.Passageiro;

public interface PassageiroRepository extends JpaRepository<Passageiro, Integer>{

}
