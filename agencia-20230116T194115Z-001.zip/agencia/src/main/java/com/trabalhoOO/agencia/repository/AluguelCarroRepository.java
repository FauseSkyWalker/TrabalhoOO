package com.trabalhoOO.agencia.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trabalhoOO.agencia.model.AluguelCarro;

public interface AluguelCarroRepository extends JpaRepository<AluguelCarro, Integer>{

}
