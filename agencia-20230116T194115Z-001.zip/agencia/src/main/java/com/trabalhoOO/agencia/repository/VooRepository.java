package com.trabalhoOO.agencia.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.trabalhoOO.agencia.model.Voo;

public interface VooRepository extends JpaRepository<Voo, Integer> {

}
