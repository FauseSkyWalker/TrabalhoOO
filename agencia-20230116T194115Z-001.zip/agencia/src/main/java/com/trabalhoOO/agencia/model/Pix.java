package com.trabalhoOO.agencia.model;

public class Pix {

}
